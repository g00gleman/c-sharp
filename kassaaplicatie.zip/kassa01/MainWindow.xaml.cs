﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void Toevoegen_Btn_Click(object sender, RoutedEventArgs e)
        {
            ProductToevoegen window = new ProductToevoegen();
            window.Show();
            this.Close();
        }

        private void Afrekenen_Btn_Click(object sender, RoutedEventArgs e)
        {
            Afrekenen window = new Afrekenen();
            window.Show();
            this.Close();
        }

        private void NiewKlant_Btn_Click(object sender, RoutedEventArgs e)
        {
            NiewKlant window = new NiewKlant();
            window.Show();
            this.Close();
        }

        private void Database_Btn_Click(object sender, RoutedEventArgs e)
        {
            Database window = new Database();
            window.Show();
            this.Close();
        }

        private void Exit_Btn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
