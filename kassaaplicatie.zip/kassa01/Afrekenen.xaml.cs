﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for Afrekenen.xaml
    /// </summary>
    public partial class Afrekenen : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        public Afrekenen()
        {
            InitializeComponent();
            cmb_K_klanten.ItemsSource = db.Klants.ToList();
            cmb_P_producten.ItemsSource = db.Products.ToList();
            dg_bestelling.ItemsSource = db.Bestellings.ToList();
        }

        private void Terug_Menu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void btn_Bestellen_Click(object sender, RoutedEventArgs e)
        {
        }

        private void btn_item_opslaan_Click (object sender, RoutedEventArgs e)
        {
            string sNaam = ((Klant)cmb_K_klanten.SelectedItem).Voornaam;
            string sProduct = ((Product)cmb_P_producten.SelectedItem).ProductNaam;
            string sAantal = txt_P_Aantal.Text;
            


            Bestelling deBestelling = new Bestelling();
            deBestelling.bestellingNaam = sNaam;
            deBestelling.bestellingProduct = sProduct;
            deBestelling.bestellingAantal = int.Parse(sAantal);
            db.Bestellings.InsertOnSubmit(deBestelling);
            db.SubmitChanges();
            dg_bestelling.ItemsSource = db.Bestellings.ToList();
            MessageBox.Show("opgeslagen!");

        }

        private void btnverwijderen_Click(object sender, RoutedEventArgs e)
        {
            Bestelling deBestelling = (Bestelling)dg_bestelling.SelectedItem;

            db.Bestellings.DeleteOnSubmit(deBestelling);
            db.SubmitChanges();

            dg_bestelling.ItemsSource = db.Bestellings.ToList();
        }
    }
}
