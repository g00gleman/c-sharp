﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for Database.xaml
    /// </summary>
    public partial class Database : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        public Database()
        {
            InitializeComponent();
            dg_Klant.ItemsSource = db.Klants.ToList();
            dgProduct.ItemsSource = db.Products.ToList();
        }

        private void Terug_Menu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { 
            
        }

        private void btnwijzig(object sender, RoutedEventArgs e)
        {
            
        }

        private void btnwijzig_Click(object sender, RoutedEventArgs e)
        {
            var klant = (Klant)dg_Klant.SelectedItem;
            wijzigen window = new wijzigen(klant, db);
            window.Show();
        }

        private void btnwijzig_Click_1(object sender, RoutedEventArgs e)
        {
            var product = (Product)dgProduct.SelectedItem;
            wijzigen1 window = new wijzigen1(product, db);
            window.Show();
        }
    }
}
