﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for wijzigen.xaml
    /// </summary>
    public partial class wijzigen : Window
    {
        private Klant Klant;
        private DataClasses1DataContext db;

        public wijzigen(Klant Klant, DataClasses1DataContext db)
        {
            InitializeComponent();
            this.Klant = Klant;
            this.db = db;

            txt_K_Voornaam.Text = Klant.Voornaam;
            txt_K_Achternaam.Text = Klant.Achternaam;
            txt_K_Adres.Text = Klant.Adres;
            txt_K_Tel.Text = Klant.TelefoonNummer.ToString();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btn_K_Wijzigen_Click(object sender, RoutedEventArgs e)
        {
                string svoornaam = txt_K_Voornaam.Text;
                string sachternaam = txt_K_Achternaam.Text;
                string sadres = txt_K_Adres.Text;
                string stel = txt_K_Tel.Text;

                Klant klant = Klant;
                klant.Voornaam = svoornaam;
                klant.Achternaam = sachternaam;
                klant.Adres = sadres;
                klant.TelefoonNummer = int.Parse(stel);

                db.SubmitChanges();
                MessageBox.Show("Alles is succsevol gewijzigd");
                this.Close();
        }
    }
}
