﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for ProductToevoegen.xaml
    /// </summary>
    public partial class ProductToevoegen : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        public ProductToevoegen()
        {
            InitializeComponent();
            cmb_P_Category.ItemsSource = db.Categories.ToList();
        }

        private void Terug_Menu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        public void resetvelden()
        {
            txt_P_Naam.Text = "";
            txt_P_Prijs.Text = "";
        }

        private void cmb_P_Category_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btn_P_Toevoegen_Click(object sender, RoutedEventArgs e)
        {
            string sproductnaam = txt_P_Naam.Text;
            string sprijs = txt_P_Prijs.Text;

            Product deProduct = new Product();
            deProduct.ProductNaam = sproductnaam;

            deProduct.ProductPrijs = decimal.Parse(sprijs);

            deProduct.categoryID = ((Category)cmb_P_Category.SelectedItem).categoryID;

            db.Products.InsertOnSubmit(deProduct);
            db.SubmitChanges();
            MessageBox.Show("opgeslagen!");
            resetvelden();
        }
    }
}
