﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for wijzigen1.xaml
    /// </summary>
    public partial class wijzigen1 : Window
    {
        private Product Product;
        private DataClasses1DataContext db;

        public wijzigen1(Product Product, DataClasses1DataContext db)
        {
            InitializeComponent();
            this.Product = Product;
            this.db = db;

            cmb_P_Category.ItemsSource = db.Categories.ToList();

            txt_P_Productnaam.Text = Product.ProductNaam;
            txt_P_Prijs.Text = Product.ProductPrijs.ToString();
            cmb_P_Category.SelectedItem = Product.Category;
        }

        private void btn_terug_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btn_K_Wijzigen_Click(object sender, RoutedEventArgs e)
        {
            string sproductnaam = txt_P_Productnaam.Text;
            string sprijs = txt_P_Prijs.Text;

            Product product = Product;
            product.ProductNaam = sproductnaam;
            product.ProductPrijs = decimal.Parse(sprijs);
            product.Category = (Category)cmb_P_Category.SelectedItem;


            db.SubmitChanges();
            MessageBox.Show("Alles is succsevol gewijzigd");
            this.Close();
        }
    }
}
