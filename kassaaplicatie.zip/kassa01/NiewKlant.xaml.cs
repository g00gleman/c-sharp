﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace kassa01
{
    /// <summary>
    /// Interaction logic for NiewKlant.xaml
    /// </summary>
    public partial class NiewKlant : Window
    {
        DataClasses1DataContext db = new DataClasses1DataContext();

        public NiewKlant()
        {
            InitializeComponent();
        }

        private void Terug_Menu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.Show();
            this.Close();
        }

        public void resetvelden()
        {
            txt_K_Voornaam.Text = "";
            txt_K_Achternaam.Text = "";
            txt_K_Adres.Text = "";
            txt_K_Tel.Text = "";
            date_K_Birth.Text = "";
        }

        private void btn_K_Toevoegen_Click(object sender, RoutedEventArgs e)
        {
            string svoornaam = txt_K_Voornaam.Text;
            string sachternaam = txt_K_Achternaam.Text;
            string sadres= txt_K_Adres.Text;
            string stel = txt_K_Tel.Text;

            Klant deKlant = new Klant();
            deKlant.Voornaam = svoornaam;
            deKlant.Achternaam = sachternaam;
            deKlant.Adres = sadres;
            deKlant.Geboorte = date_K_Birth.SelectedDate;
            deKlant.TelefoonNummer = int.Parse(stel);

            db.Klants.InsertOnSubmit(deKlant);
            db.SubmitChanges();
            MessageBox.Show("opgeslagen!");
            resetvelden();
        }
    }
}
